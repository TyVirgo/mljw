export const classroomTypeOptions = ['General Classroom', 'Lab', 'Lecture Hall', 'Seminar Room']
export const deskChairTypeOptions = ['Fixed desk and chair', 'Movable desk and chair', 'Tiered seating']
export const equipmentOptions = ['mic', 'projector', 'whiteboard', 'smart board']
export const softwareOptions = ['Windows', 'Linux', 'macOS', 'Office']
export const departmentOptions = ['Computer Science', 'Engineering', 'Business', 'Arts', 'Science']

export const initialClassrooms = [
  {
    id: 1,
    block: 'A1',
    floor: '1F',
    classroomNo: 'A1-101',
    classroom: 'A1-101',
    classroomName: 'A1-101 Classroom',
    classroomNameEn: 'A1-101 Classroom',
    classroomNameMal: 'Bilik Darjah A1-101',
    classroomType: 'General Classroom',
    deskChairType: 'Fixed desk and chair',
    capacity: 60,
    availableSeats: 55,
    examSeats: 60,
    classroomEquipment: 'mic, projector',
    software: 'Windows',
    activation: true,
    commonArea: false,
    borrowingAvailability: true,
    userDepartment: 'Computer Science',
    remark: '',
  },
  {
    id: 2,
    block: 'A2',
    floor: '2F',
    classroomNo: 'A2-201',
    classroom: 'A2-201',
    classroomName: 'A2-201 Classroom',
    classroomNameEn: 'A2-201 Classroom',
    classroomNameMal: 'Bilik Darjah A2-201',
    classroomType: 'General Classroom',
    deskChairType: 'Fixed desk and chair',
    capacity: 80,
    availableSeats: 75,
    examSeats: 80,
    classroomEquipment: 'mic, projector',
    software: 'Windows',
    activation: true,
    commonArea: false,
    borrowingAvailability: true,
    userDepartment: 'Engineering',
    remark: '',
  },
  {
    id: 3,
    block: 'A3',
    floor: '1F',
    classroomNo: 'A3-102',
    classroom: 'A3-102',
    classroomName: 'A3-102 Classroom',
    classroomNameEn: 'A3-102 Classroom',
    classroomNameMal: 'Bilik Darjah A3-102',
    classroomType: 'Lab',
    deskChairType: 'Movable desk and chair',
    capacity: 40,
    availableSeats: 38,
    examSeats: 40,
    classroomEquipment: 'mic, projector, whiteboard',
    software: 'Windows, Office',
    activation: true,
    commonArea: false,
    borrowingAvailability: false,
    userDepartment: 'Computer Science',
    remark: '',
  },
  {
    id: 4,
    block: 'A4',
    floor: 'GF',
    classroomNo: 'A4-001',
    classroom: 'A4-001',
    classroomName: 'A4-001 Classroom',
    classroomNameEn: 'A4-001 Classroom',
    classroomNameMal: 'Bilik Darjah A4-001',
    classroomType: 'Lecture Hall',
    deskChairType: 'Tiered seating',
    capacity: 120,
    availableSeats: 115,
    examSeats: 120,
    classroomEquipment: 'mic, projector',
    software: 'Windows',
    activation: true,
    commonArea: true,
    borrowingAvailability: true,
    userDepartment: 'Business',
    remark: '',
  },
  {
    id: 5,
    block: 'A5',
    floor: '1F',
    classroomNo: 'A5-103',
    classroom: 'A5-103',
    classroomName: 'A5-103 Classroom',
    classroomNameEn: 'A5-103 Classroom',
    classroomNameMal: 'Bilik Darjah A5-103',
    classroomType: 'General Classroom',
    deskChairType: 'Fixed desk and chair',
    capacity: 50,
    availableSeats: 48,
    examSeats: 50,
    classroomEquipment: 'projector',
    software: 'Windows',
    activation: false,
    commonArea: false,
    borrowingAvailability: false,
    userDepartment: 'Arts',
    remark: '',
  },
  {
    id: 6,
    block: 'B1',
    floor: '2F',
    classroomNo: 'B1-202',
    classroom: 'B1-202',
    classroomName: 'B1-202 Classroom',
    classroomNameEn: 'B1-202 Classroom',
    classroomNameMal: 'Bilik Darjah B1-202',
    classroomType: 'Seminar Room',
    deskChairType: 'Movable desk and chair',
    capacity: 30,
    availableSeats: 28,
    examSeats: 30,
    classroomEquipment: 'mic, projector',
    software: 'macOS',
    activation: true,
    commonArea: false,
    borrowingAvailability: true,
    userDepartment: 'Science',
    remark: '',
  },
  {
    id: 7,
    block: 'B2',
    floor: '1F',
    classroomNo: 'B2-101',
    classroom: 'B2-101',
    classroomName: 'B2-101 Classroom',
    classroomNameEn: 'B2-101 Classroom',
    classroomNameMal: 'Bilik Darjah B2-101',
    classroomType: 'General Classroom',
    deskChairType: 'Fixed desk and chair',
    capacity: 65,
    availableSeats: 60,
    examSeats: 65,
    classroomEquipment: 'mic, projector',
    software: 'Windows',
    activation: true,
    commonArea: false,
    borrowingAvailability: true,
    userDepartment: 'Engineering',
    remark: '',
  },
  {
    id: 8,
    block: 'C1',
    floor: '2F',
    classroomNo: 'C1-201',
    classroom: 'C1-201',
    classroomName: 'C1-201 Classroom',
    classroomNameEn: 'C1-201 Classroom',
    classroomNameMal: 'Bilik Darjah C1-201',
    classroomType: 'Lab',
    deskChairType: 'Fixed desk and chair',
    capacity: 35,
    availableSeats: 32,
    examSeats: 35,
    classroomEquipment: 'smart board',
    software: 'Linux',
    activation: true,
    commonArea: false,
    borrowingAvailability: false,
    userDepartment: 'Computer Science',
    remark: '',
  },
  {
    id: 9,
    block: 'C2',
    floor: '3F',
    classroomNo: 'C2-301',
    classroom: 'C2-301',
    classroomName: 'C2-301 Classroom',
    classroomNameEn: 'C2-301 Classroom',
    classroomNameMal: 'Bilik Darjah C2-301',
    classroomType: 'General Classroom',
    deskChairType: 'Fixed desk and chair',
    capacity: 70,
    availableSeats: 68,
    examSeats: 70,
    classroomEquipment: 'mic, projector',
    software: 'Windows',
    activation: true,
    commonArea: true,
    borrowingAvailability: true,
    userDepartment: 'Business',
    remark: '',
  },
  {
    id: 10,
    block: 'D1',
    floor: 'GF',
    classroomNo: 'D1-002',
    classroom: 'D1-002',
    classroomName: 'D1-002 Classroom',
    classroomNameEn: 'D1-002 Classroom',
    classroomNameMal: 'Bilik Darjah D1-002',
    classroomType: 'General Classroom',
    deskChairType: 'Fixed desk and chair',
    capacity: 45,
    availableSeats: 42,
    examSeats: 45,
    classroomEquipment: 'projector',
    software: 'Windows',
    activation: true,
    commonArea: false,
    borrowingAvailability: true,
    userDepartment: 'Arts',
    remark: '',
  },
]

let nextId = 11

export function createClassroomId() {
  return nextId++
}

export function buildClassroomCode(block, classroomNo) {
  if (!block || !classroomNo) return ''
  const no = classroomNo.trim()
  if (no.startsWith(`${block}-`)) return no
  return `${block}-${no}`
}

export function getUserDepartments(item) {
  if (Array.isArray(item.userDepartments) && item.userDepartments.length) {
    return item.userDepartments
  }
  return item.userDepartment ? item.userDepartment.split(',').map((d) => d.trim()).filter(Boolean) : []
}

export function setUserDepartments(item, departments) {
  item.userDepartments = [...departments]
  item.userDepartment = departments.join(', ')
}

export function parseMultiSelectValue(value) {
  if (!value) return []
  return String(value).split(',').map((item) => item.trim()).filter(Boolean)
}

export function joinMultiSelectValue(values) {
  return values.join(', ')
}
